﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BadAPISolution.UI.Models
{
    public class TweetRequestDTO
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}